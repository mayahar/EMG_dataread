# Contributing to the TMSi Python interface

You are welcome to to add any contributions to the TMSi Python interface.
This can be a bug fix, improvement or a new feature. Please use the 'Development' branch for your mergerequest.

All mergerequests will be reviewed before they are accepted and included into the TMSi Python interface.
